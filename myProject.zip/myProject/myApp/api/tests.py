from rest_framework.test import APITestCase
import json
from bs4 import BeautifulSoup


class ListAPIViewTestCase(APITestCase):
    def setUp(self):
        web_response = self.client.get("http://127.0.0.1:8000/") # trigger the main.html to genarate a random number
        soup = BeautifulSoup(web_response.content.decode(), 'lxml') # scrape the HTTP response
        self.num = soup.strong.text # pull the number from it's tags
        self.url = "http://127.0.0.1:8000/api/" # the api url

    def test_api_bundle(self):
        api_response = self.client.get(self.url) # get the api's response
        self.assertEqual(200, api_response.status_code) # check if went well

        response_data = json.loads(api_response.content) # format the data from the HTTP response
        
        # DEBUG ONLY !
        with open('my_data.txt', 'w') as file: 
            file.write("web: " + str(self.num))
            file.write("\napi: " + str(response_data['number']))

        self.assertEqual(int(self.num), response_data['number']) # check whether the api equals to the website