from rest_framework.decorators import api_view
from rest_framework.response import Response
import myApp.views as appView

@api_view(['GET'])
def getNumber(request):
    return Response({'number':appView.num})