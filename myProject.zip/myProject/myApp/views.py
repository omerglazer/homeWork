from django.shortcuts import render
import random

# Create your views here.

num = 0

def home(request):
    global num
    num = random.randint(1,100)
    context = {'num':num}
    return render(request, 'home.html', context)
